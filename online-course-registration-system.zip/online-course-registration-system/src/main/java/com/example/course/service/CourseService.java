package com.example.course.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.course.entity.Course;
import com.example.course.entity.Student;
import com.example.course.repository.CourseRepository;
import com.example.course.repository.StudentRepository;

@Service
public class CourseService {
    
    @Autowired
    private CourseRepository courseRepository;
    
    @Autowired
    private StudentRepository studentRepository;

    @Transactional
    public void enrollStudentInCourse(Long studentId, Long courseId) {
        Optional<Student> studentOpt = studentRepository.findById(studentId);
        Optional<Course> courseOpt = courseRepository.findById(courseId);
        
        if (studentOpt.isPresent() && courseOpt.isPresent()) {
            Student student = studentOpt.get();
            Course course = courseOpt.get();
            
            // Check if the student is already enrolled in the course
            if (student.getCourses().contains(course)) {
                throw new IllegalArgumentException("Student is already enrolled in this course");
            }

            // Enroll the student in the course
            student.getCourses().add(course);
            course.getStudents().add(student);

            studentRepository.save(student);
            courseRepository.save(course);
        } else {
            throw new IllegalArgumentException("Student or Course not found");
        }
    }

    @Transactional
    public void unenrollStudentFromCourse(Long studentId, Long courseId) {
        Optional<Student> studentOpt = studentRepository.findById(studentId);
        Optional<Course> courseOpt = courseRepository.findById(courseId);

        if (studentOpt.isPresent() && courseOpt.isPresent()) {
            Student student = studentOpt.get();
            Course course = courseOpt.get();

            // Check if the student is enrolled in the course
            if (!student.getCourses().contains(course)) {
                throw new IllegalArgumentException("Student is not enrolled in this course");
            }

            // Unenroll the student from the course
            student.getCourses().remove(course);
            course.getStudents().remove(student);

            studentRepository.save(student);
            courseRepository.save(course);
        } else {
            throw new IllegalArgumentException("Student or Course not found");
        }
    }

    public List<Course> getCoursesForStudent(Long studentId) {
        return studentRepository.findById(studentId)
                .map(Student::getCourses)
                .map(List::copyOf)
                .orElseThrow(() -> new IllegalArgumentException("Student not found"));
    }

    public List<Student> getStudentsInCourse(Long courseId) {
        return courseRepository.findById(courseId)
                .map(Course::getStudents)
                .map(List::copyOf)
                .orElseThrow(() -> new IllegalArgumentException("Course not found"));
    }
}
