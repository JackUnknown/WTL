package com.example.taskmanagement.entity;

public enum Status {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
